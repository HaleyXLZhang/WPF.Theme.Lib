﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;
namespace NavigationTheme
{
    public class MainWindow : Window
    {
        static MainWindow()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(MainWindow), new FrameworkPropertyMetadata(typeof(MainWindow)));
        }
        private PropertyChangedEventHandler PropertyChangedEvent;
        public event PropertyChangedEventHandler PropertyChanged
        {
            add
            {
                this.PropertyChangedEvent = (PropertyChangedEventHandler)Delegate.Combine(this.PropertyChangedEvent, value);
            }
            remove
            {
                this.PropertyChangedEvent = (PropertyChangedEventHandler)Delegate.Remove(this.PropertyChangedEvent, value);
            }
        }
        private ObservableCollection<MenuItem> _Menu;
        public ObservableCollection<MenuItem> Menu
        {
            get { return this._Menu; }
            set { this._Menu = value; }
        }
        public string UserName { get; set; }
        public string ApplicationVersion { get; set; }
        public string UserIconImageUrl { get; set; }
        public PagesControl PageControlBar { get; set; }
        public MainWindow()
        {
            UserName = Environment.UserName;
            this.AllowsTransparency = true;
            this.WindowStyle = WindowStyle.None;
            ApplicationVersion = Assembly.GetExecutingAssembly().GetName().Version.ToString();
            this.AddHandler(Button.ClickEvent, new RoutedEventHandler(ButtonClicked));

            this.MouseMove += MainWindow_MouseMove;
            //User icon
            System.Windows.Controls.Image image = this.GetTemplateChild("ImageUrl") as System.Windows.Controls.Image;
            if (image != null && image.Visibility == Visibility.Visible)
            {
                BitmapImage bitmapImage = new BitmapImage();
                bitmapImage.BeginInit();
                bitmapImage.UriSource = new Uri("http://photos.global.hsbc/casual/square/" + Environment.UserName.Substring(0, 4) + "/" + Environment.UserName + ".jpg");
                bitmapImage.EndInit();
                image.Source = bitmapImage;
            }
            this.DMWindowShadowColor = Color.FromArgb(136, 136, 136);
            this.DMWindowShadowOpacity = 0.9;
            this.DMWindowShadowSize = 20;
        }

        private void MainWindow_MouseMove(object sender, MouseEventArgs e)
        {
            System.Windows.Point pp = Mouse.GetPosition(this);
            if (pp.X <= this.ActualWidth && pp.Y <= SystemParameters.CaptionHeight + 48 + 20)
            {
                if (e.LeftButton == MouseButtonState.Pressed)
                {
                    this.DragMove();
                }
            }
        }
        Thickness MaxThickness = new Thickness(0);
        Thickness NormalThickness = new Thickness(20);
        private void ButtonClicked(object sender, RoutedEventArgs e)
        {
            if ((e.OriginalSource as FrameworkElement).Name.Contains("closeButton")) { this.Close(); }
            if ((e.OriginalSource as FrameworkElement).Name.Contains("minimizeButton"))
            {
                this.WindowState = System.Windows.WindowState.Minimized;
            }
            if ((e.OriginalSource as FrameworkElement).Name.Contains("restoreButton"))
            {
                Opacity = 0;
                this.WindowState = (WindowState)((this.WindowState == WindowState.Normal) ? 2 : 0);
                //最大化
                if (WindowState == WindowState.Maximized)
                {
                    BorderThickness = MaxThickness;
                }
                //默认大小
                if (WindowState == WindowState.Normal)
                {
                    BorderThickness = NormalThickness;
                }
                //最小化-隐藏阴影
                if (WindowState == WindowState.Minimized)
                {

                }
                Opacity = 1;
            }
        }
        #region 窗体属性
        [Description("全屏是否保留任务栏显示"), Category("DMSkin")]
        public bool DMFullScreen
        {
            get { return (bool)GetValue(DMFullScreenProperty); }
            set { SetValue(DMFullScreenProperty, value); }
        }
        public static readonly DependencyProperty DMFullScreenProperty =
            DependencyProperty.Register("DMFullScreen", typeof(bool), typeof(MainWindow), new PropertyMetadata(false));


        [Description("窗体阴影大小"), Category("DMSkin")]
        public int DMWindowShadowSize
        {
            get { return (int)GetValue(DMWindowShadowSizeProperty); }
            set { SetValue(DMWindowShadowSizeProperty, value); }
        }
        public static readonly DependencyProperty DMWindowShadowSizeProperty =
            DependencyProperty.Register("DMWindowShadowSize", typeof(int), typeof(MainWindow), new PropertyMetadata(10));

        [Description("窗体阴影颜色"), Category("DMSkin")]
        public Color DMWindowShadowColor
        {
            get { return (Color)GetValue(DMWindowShadowColorProperty); }
            set { SetValue(DMWindowShadowColorProperty, value); }
        }
        public static readonly DependencyProperty DMWindowShadowColorProperty =
            DependencyProperty.Register("DMWindowShadowColor", typeof(Color), typeof(MainWindow), new PropertyMetadata(Color.FromArgb(255, 200, 200, 200)));

        [Description("窗体阴影透明度"), Category("DMSkin")]
        public double DMWindowShadowOpacity
        {
            get { return (double)GetValue(DMWindowShadowOpacityProperty); }
            set { SetValue(DMWindowShadowOpacityProperty, value); }
        }
        public static readonly DependencyProperty DMWindowShadowOpacityProperty =
            DependencyProperty.Register("DMWindowShadowOpacity", typeof(double), typeof(MainWindow), new PropertyMetadata(1.0));
        #endregion
    }
}
