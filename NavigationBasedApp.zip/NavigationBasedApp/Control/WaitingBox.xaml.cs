﻿using System.ComponentModel;
using System.Drawing;

namespace System.Windows
{
    /// <summary>
    /// 简单等待框
    /// </summary>
    public partial class WaitingBox : Window
    {
        public string Text { get { return this.txtMessage.Text; } set { this.txtMessage.Text = value; } }
        private static Window _parentWindow;
        private Action _Callback;
        private Func<string> _Func;

        public WaitingBox(Action callback)
        {
            InitializeComponent();
            this._Callback = callback;
            this.Loaded += WaitingBox_Loaded;
            this.DMWindowShadowColor = Color.FromArgb(136, 136, 136);
            this.DMWindowShadowOpacity = 0.9;
            this.DMWindowShadowSize = 20;
            this.btnOK.Visibility = Visibility.Collapsed;
        }

        public WaitingBox(Func<string> func)
        {
            InitializeComponent();
            this._Func = func;
            this.Loaded += WaitingBox_Loaded;
            this.DMWindowShadowColor = Color.FromArgb(136, 136, 136);
            this.DMWindowShadowOpacity = 0.9;
            this.DMWindowShadowSize = 20;
        }

        void WaitingBox_Loaded(object sender, RoutedEventArgs e)
        {

            if (this._Func != null)
            {
                this._Func.BeginInvoke(this.OnComplateFunc, null);
                
            }
            else
            {
                this._Callback.BeginInvoke(this.OnComplate, null);
            }
        }

        private void OnComplate(IAsyncResult ar)
        {
            this.Dispatcher.Invoke(new Action(() =>
            {
                this.Close();
            }));
        }
        private void OnComplateFunc(IAsyncResult ar)
        {
            this.Dispatcher.Invoke(new Action(() =>
            {
                string message = this._Func.EndInvoke(ar);
                this.Text = message;
            }));
        }

        #region 窗体属性
        [Description("全屏是否保留任务栏显示"), Category("DMSkin")]
        public bool DMFullScreen
        {
            get { return (bool)GetValue(DMFullScreenProperty); }
            set { SetValue(DMFullScreenProperty, value); }
        }
        public static readonly DependencyProperty DMFullScreenProperty =
            DependencyProperty.Register("DMFullScreen", typeof(bool), typeof(Window), new PropertyMetadata(false));


        [Description("窗体阴影大小"), Category("DMSkin")]
        public int DMWindowShadowSize
        {
            get { return (int)GetValue(DMWindowShadowSizeProperty); }
            set { SetValue(DMWindowShadowSizeProperty, value); }
        }
        public static readonly DependencyProperty DMWindowShadowSizeProperty =
            DependencyProperty.Register("DMWindowShadowSize", typeof(int), typeof(Window), new PropertyMetadata(10));

        [Description("窗体阴影颜色"), Category("DMSkin")]
        public Color DMWindowShadowColor
        {
            get { return (Color)GetValue(DMWindowShadowColorProperty); }
            set { SetValue(DMWindowShadowColorProperty, value); }
        }
        public static readonly DependencyProperty DMWindowShadowColorProperty =
            DependencyProperty.Register("DMWindowShadowColor", typeof(Color), typeof(Window), new PropertyMetadata(Color.FromArgb(255, 200, 200, 200)));

        [Description("窗体阴影透明度"), Category("DMSkin")]
        public double DMWindowShadowOpacity
        {
            get { return (double)GetValue(DMWindowShadowOpacityProperty); }
            set { SetValue(DMWindowShadowOpacityProperty, value); }
        }
        public static readonly DependencyProperty DMWindowShadowOpacityProperty =
            DependencyProperty.Register("DMWindowShadowOpacity", typeof(double), typeof(Window), new PropertyMetadata(1.0));
        #endregion

        /// <summary>
        /// 显示等待框，callback为需要执行的方法体（需要自己做异常处理）。
        /// 目前等等框为模式窗体
        /// </summary>
        public static void Show(Action callback, string mes = "message...")
        {
            WaitingBox win = new WaitingBox(callback);
            Window pwin = ControlHelper.GetTopWindow();
            win.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            win.Owner = pwin;
            win.Text = mes;
            win.ShowDialog();
        }

        public static void Show(Window parentWindow, Func<string> callback, string mes = "message...")
        {
            _parentWindow = parentWindow;
            WaitingBox win = new WaitingBox(callback);
            Window pwin = ControlHelper.GetTopWindow();
            win.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            win.Owner = pwin;
            win.Text = mes;
            win.ShowDialog();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            _parentWindow.Close();
            _parentWindow = null;
        }
    }
}
